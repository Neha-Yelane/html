import pandas as pd
from pulp import LpProblem, LpMinimize, LpVariable, lpSum

# Load dataset
data = pd.read_csv("sample_dataset.csv")

# Define LP problem
model = LpProblem("Carbon_Footprint_Optimization", LpMinimize)

# Decision variables: fraction of shipment by each mode
x = {mode: LpVariable(mode, 0, 1) for mode in data["Mode"]}

# Objective: minimize (Cost + Carbon penalty)
penalty = 10  # weight for carbon impact
model += lpSum([
    x[row.Mode] * (row.Distance_km * row.Cost_per_km + penalty * row.Distance_km * row.Weight_ton * row.Emission_factor)
    for _, row in data.iterrows()
])

# Constraint: must transport 100% of goods
model += lpSum([x[mode] for mode in data["Mode"]]) == 1

# Solve
model.solve()

print("\n--- Optimal Allocation ---")
for mode in data["Mode"]:
    print(f"{mode}: {x[mode].value() * 100:.2f}%")

print("\nOptimization complete ✅")
