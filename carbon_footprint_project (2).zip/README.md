# Carbon Footprint Optimization in Supply Chain Logistics

## 📌 Project Overview
This project calculates and optimizes carbon emissions in supply chain logistics using Python.  
It helps in identifying the most cost-efficient and eco-friendly transportation options.

## 🚛 Features
- Emission calculation by transport mode (Truck, Rail, Ship, Air)
- Cost + Carbon minimization using Linear Programming (PuLP)
- Visualizations of emissions and optimization results
- Ready-to-use dataset and sample outputs

## ⚙️ Installation
```bash
git clone https://github.com/Neha-Yelane/carbon-footprint-optimization.git
cd carbon-footprint-optimization
pip install -r requirements.txt
```

## ▶️ Usage
```bash
python calculate_emissions.py
python optimize_routes.py
```

## 📊 Results
- Carbon emissions per transport mode
- Optimized logistics cost vs. carbon output
- Graphs and tables for analysis

## 🙌 Contributor
- Neha Yelane
