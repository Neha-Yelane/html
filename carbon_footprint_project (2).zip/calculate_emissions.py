import pandas as pd

# Load dataset
data = pd.read_csv("sample_dataset.csv")

# Calculate emissions
data["Emissions"] = data["Distance_km"] * data["Weight_ton"] * data["Emission_factor"]

# Calculate cost
data["Cost"] = data["Distance_km"] * data["Cost_per_km"]

print("\n--- Transport Data with Emissions & Cost ---\n")
print(data)

print("\nTotal Emissions:", data["Emissions"].sum(), "kg CO2")
print("Total Cost:", data["Cost"].sum(), "units")
